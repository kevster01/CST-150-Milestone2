﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST_Project_1
{
    public partial class AdminPortal : Form
    {
        public AdminPortal()
        {
            InitializeComponent();
        }

        private void newAdmin_btn_Click(object sender, EventArgs e)
        {

        }

        private void modMembers_btn_Click(object sender, EventArgs e)
        {

        }

        private void newMember_btn_Click(object sender, EventArgs e)
        {

        }

        private void newStaff_btn_Click(object sender, EventArgs e)
        {

        }

        private void newClass_btn_Click(object sender, EventArgs e)
        {

        }

        private void modClass_btn_Click(object sender, EventArgs e)
        {

        }

        private void modStaff_btn_Click(object sender, EventArgs e)
        {

        }

        private void modAdmin_btn_Click(object sender, EventArgs e)
        {

        }
    }
}
