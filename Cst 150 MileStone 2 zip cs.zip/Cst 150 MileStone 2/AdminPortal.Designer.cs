﻿namespace CST_Project_1
{
    partial class AdminPortal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPortal));
            this.newMember_btn = new System.Windows.Forms.Button();
            this.newStaff_btn = new System.Windows.Forms.Button();
            this.modMembers_btn = new System.Windows.Forms.Button();
            this.modStaff_btn = new System.Windows.Forms.Button();
            this.newClass_btn = new System.Windows.Forms.Button();
            this.modClass_btn = new System.Windows.Forms.Button();
            this.newAdmin_btn = new System.Windows.Forms.Button();
            this.modAdmin_btn = new System.Windows.Forms.Button();
            this.welcome_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newMember_btn
            // 
            this.newMember_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.newMember_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newMember_btn.Location = new System.Drawing.Point(83, 150);
            this.newMember_btn.Name = "newMember_btn";
            this.newMember_btn.Size = new System.Drawing.Size(188, 30);
            this.newMember_btn.TabIndex = 0;
            this.newMember_btn.Text = "Add New Member";
            this.newMember_btn.UseVisualStyleBackColor = false;
            this.newMember_btn.Click += new System.EventHandler(this.newMember_btn_Click);
            // 
            // newStaff_btn
            // 
            this.newStaff_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.newStaff_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newStaff_btn.Location = new System.Drawing.Point(83, 292);
            this.newStaff_btn.Name = "newStaff_btn";
            this.newStaff_btn.Size = new System.Drawing.Size(188, 30);
            this.newStaff_btn.TabIndex = 0;
            this.newStaff_btn.Text = "Add New Staff";
            this.newStaff_btn.UseVisualStyleBackColor = false;
            this.newStaff_btn.Click += new System.EventHandler(this.newStaff_btn_Click);
            // 
            // modMembers_btn
            // 
            this.modMembers_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.modMembers_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modMembers_btn.Location = new System.Drawing.Point(486, 150);
            this.modMembers_btn.Name = "modMembers_btn";
            this.modMembers_btn.Size = new System.Drawing.Size(188, 30);
            this.modMembers_btn.TabIndex = 0;
            this.modMembers_btn.Text = "Modify Members";
            this.modMembers_btn.UseVisualStyleBackColor = false;
            this.modMembers_btn.Click += new System.EventHandler(this.modMembers_btn_Click);
            // 
            // modStaff_btn
            // 
            this.modStaff_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.modStaff_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modStaff_btn.Location = new System.Drawing.Point(486, 292);
            this.modStaff_btn.Name = "modStaff_btn";
            this.modStaff_btn.Size = new System.Drawing.Size(188, 30);
            this.modStaff_btn.TabIndex = 0;
            this.modStaff_btn.Text = "Modify Staff";
            this.modStaff_btn.UseVisualStyleBackColor = false;
            this.modStaff_btn.Click += new System.EventHandler(this.modStaff_btn_Click);
            // 
            // newClass_btn
            // 
            this.newClass_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.newClass_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newClass_btn.Location = new System.Drawing.Point(83, 365);
            this.newClass_btn.Name = "newClass_btn";
            this.newClass_btn.Size = new System.Drawing.Size(188, 30);
            this.newClass_btn.TabIndex = 0;
            this.newClass_btn.Text = "Add New Class";
            this.newClass_btn.UseVisualStyleBackColor = false;
            this.newClass_btn.Click += new System.EventHandler(this.newClass_btn_Click);
            // 
            // modClass_btn
            // 
            this.modClass_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.modClass_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modClass_btn.Location = new System.Drawing.Point(486, 365);
            this.modClass_btn.Name = "modClass_btn";
            this.modClass_btn.Size = new System.Drawing.Size(188, 30);
            this.modClass_btn.TabIndex = 0;
            this.modClass_btn.Text = "Modify Class";
            this.modClass_btn.UseVisualStyleBackColor = false;
            this.modClass_btn.Click += new System.EventHandler(this.modClass_btn_Click);
            // 
            // newAdmin_btn
            // 
            this.newAdmin_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.newAdmin_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newAdmin_btn.Location = new System.Drawing.Point(83, 221);
            this.newAdmin_btn.Name = "newAdmin_btn";
            this.newAdmin_btn.Size = new System.Drawing.Size(188, 30);
            this.newAdmin_btn.TabIndex = 0;
            this.newAdmin_btn.Text = "Add New Admin Staff";
            this.newAdmin_btn.UseVisualStyleBackColor = false;
            this.newAdmin_btn.Click += new System.EventHandler(this.newAdmin_btn_Click);
            // 
            // modAdmin_btn
            // 
            this.modAdmin_btn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.modAdmin_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modAdmin_btn.Location = new System.Drawing.Point(486, 221);
            this.modAdmin_btn.Name = "modAdmin_btn";
            this.modAdmin_btn.Size = new System.Drawing.Size(188, 30);
            this.modAdmin_btn.TabIndex = 0;
            this.modAdmin_btn.Text = "Modify Admin Staff";
            this.modAdmin_btn.UseVisualStyleBackColor = false;
            this.modAdmin_btn.Click += new System.EventHandler(this.modAdmin_btn_Click);
            // 
            // welcome_lbl
            // 
            this.welcome_lbl.AutoSize = true;
            this.welcome_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcome_lbl.Location = new System.Drawing.Point(271, 30);
            this.welcome_lbl.Name = "welcome_lbl";
            this.welcome_lbl.Size = new System.Drawing.Size(279, 55);
            this.welcome_lbl.TabIndex = 1;
            this.welcome_lbl.Text = "WELCOME";
            // 
            // AdminPortal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.welcome_lbl);
            this.Controls.Add(this.modStaff_btn);
            this.Controls.Add(this.modClass_btn);
            this.Controls.Add(this.modAdmin_btn);
            this.Controls.Add(this.modMembers_btn);
            this.Controls.Add(this.newAdmin_btn);
            this.Controls.Add(this.newStaff_btn);
            this.Controls.Add(this.newClass_btn);
            this.Controls.Add(this.newMember_btn);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminPortal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Portal ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button newMember_btn;
        private System.Windows.Forms.Button newStaff_btn;
        private System.Windows.Forms.Button modMembers_btn;
        private System.Windows.Forms.Button modStaff_btn;
        private System.Windows.Forms.Button newClass_btn;
        private System.Windows.Forms.Button modClass_btn;
        private System.Windows.Forms.Button newAdmin_btn;
        private System.Windows.Forms.Button modAdmin_btn;
        private System.Windows.Forms.Label welcome_lbl;
    }
}